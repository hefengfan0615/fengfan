/* ======================================================================
 *  pikafish-engine.js — Pikafish UCI 引擎桥接层
 *
 *  提供与 board.js 兼容的 Search 接口，
 *  内部通过 Web Worker 与 Pikafish WASM 引擎通信（UCI 协议）。
 *
 *  用法：
 *    var search = new PikafishUciSearch(pos, hashLevel);
 *    search.init(wasmBinary, engineJs).then(() => { ... });
 *    // 然后 board.js 会调用 search.searchMain(depth, millis)
 * ====================================================================== */

"use strict";

/* ---------- 坐标转换 (xqwlight ↔ UCI) ----------
 *
 * xqwlight:
 *   棋盘 256 格 (16x16)，有效范围: x=3..11, y=3..12
 *   COORD_XY(x, y) = x + (y << 4)
 *   FILE_X(sq) = sq & 15,  RANK_Y(sq) = sq >> 4
 *   FEN: y=3 对应第 1 行（黑方底线 rank9）
 *        y=12 对应第 10 行（红方底线 rank0）
 *
 * Pikafish (UCI):
 *   Square: 0..89, make_square(f, r) = r * 9 + f
 *   file: 0='a'..8='i', rank: 0='0'..9='9'
 *   UCI 坐标: 'a'+file + '0'+rank  例如 "e2"
 *   FEN 第 1 行 = rank9, 第 10 行 = rank0
 *
 * 映射:
 *   uciFile = xqwX - 3           (3→0, 11→8)
 *   uciRank = 12 - xqwY          (3→9, 12→0)
 *   xqwX = uciFile + 3
 *   xqwY = 12 - uciRank
 * ====================================================================== */

/* 将 xqwlight 内部 move 转为 UCI 字符串 (如 "e2e4") */
function xqwMoveToUci(mv) {
  if (!mv) return "";
  var sqSrc = mv & 255;
  var sqDst = mv >> 8;
  var srcFile = (sqSrc & 15) - 3;       // FILE_X - FILE_LEFT
  var srcRank = 12 - (sqSrc >> 4);      // 12 - RANK_Y
  var dstFile = (sqDst & 15) - 3;
  var dstRank = 12 - (sqDst >> 4);
  return String.fromCharCode(97 + srcFile) + String.fromCharCode(48 + srcRank) +
         String.fromCharCode(97 + dstFile) + String.fromCharCode(48 + dstRank);
}

/* 将 UCI 字符串 (如 "e2e4") 转为 xqwlight 内部 move */
function uciToXqwMove(uciStr) {
  if (!uciStr || uciStr.length < 4) return 0;
  var srcFile = uciStr.charCodeAt(0) - 97;     // 'a' → 0
  var srcRank = uciStr.charCodeAt(1) - 48;      // '0' → 0
  var dstFile = uciStr.charCodeAt(2) - 97;
  var dstRank = uciStr.charCodeAt(3) - 48;
  var sqSrc = (srcFile + 3) + ((12 - srcRank) << 4);
  var sqDst = (dstFile + 3) + ((12 - dstRank) << 4);
  return sqSrc + (sqDst << 8);  // MOVE(sqSrc, sqDst)
}

/* ---------- UCI 提醒消息 ---------- */
function getRuleReminders() {
  return [
    "本对局使用 Pikafish 引擎，遵守中国象棋竞赛规则。",
    "━━━ 棋规提醒 ━━━",
    "1. 长将、长捉、长杀等长打着法作负。",
    "2. 双方均为长打，或一方长打一方非长打，长打方作负。",
    "3. 双方均为非长打，不变作和。",
    "4. 一打一闲，非长打方变着，不变作和。",
    "5. 自然限着为 60 回合（未吃子）。",
    "6. 禁止着法：长将、长捉（无根子）、长杀。",
    "7. 允许着法：长拦、长跟、长兑、长献。",
    "8. 将帅对面视为\"将\"，长将帅对面亦为长打。",
    "9. 送吃不属于捉。",
    "10. 兵（卒）捉子不按捉处理，但长兵捉车除外。",
    "━━━ 引擎信息 ━━━",
  ];
}

/* ---------- PikafishUciSearch ----------
 *  兼容 board.js 中 Search 类的接口
 *  提供 searchMain(depth, millis) 方法
 *  采用"Worker 常驻 + 引擎复用"模式
 */
function PikafishUciSearch(pos, hashLevel) {
  this.pos = pos;
  this.hashLevel = hashLevel || 16;
  this.wasmBinary = null;
  this.engineJs = null;
  this.nnueData = null;    // NNUE 权重（独立加载，与 wasm 分离缓存）
  this.worker = null;
  this.engineReady = false;
  this.pendingCallback = null;
  this.stdoutBuffer = [];
  this.bestmove = "";
  this.onUciStdout = null;   // 外部可设置此回调显示 UCI 输出
  this.onUciStderr = null;
  this.onUciDebug = null;
  this.uciReminders = getRuleReminders();
  this.lastInfo = null;      // 存储最后一次 info depth score nodes pv
  this.onInfo = null;        // info 更新回调（实时）
  this.startFen = null;      // 开局 FEN，用于构建含完整历史着法的 UCI position 命令
  // 持久引擎：Worker 常驻，每个搜索通过 searchId 追踪
  this._currentSearchId = 0;
  this._pendingSearch = null;  // { resolve, reject, searchId, timeoutId }
}

/* 设置开局 FEN */
PikafishUciSearch.prototype.setStartFen = function(fen) {
  this.startFen = fen;
};

/* 初始化：下载引擎 WASM/JS/NNUE（如果未缓存）或接受已有缓存 */
PikafishUciSearch.prototype.init = function(wasmBinary, engineJs, nnueData) {
  var self = this;
  if (wasmBinary && engineJs && nnueData) {
    self.wasmBinary = wasmBinary;
    self.engineJs = engineJs;
    self.nnueData = nnueData;
    return Promise.resolve();
  }
  // 如果没有传入，从服务器加载
  return self._downloadEngine();
};

/* 引擎版本：与 sw.js / xqwlight/sw.js 保持一致 */
var ENGINE_VERSION = "20260813-151218";
var ENGINE_QUERY = "?v=" + ENGINE_VERSION;

/* relaxed SIMD 特性检测：与 pikafish.html 中同步，决定下载哪份引擎二进制。
 * 模块字节来自 wasm-feature-detect 库（Google Chrome Labs）经实测可正确编译。 */
var USE_RELAXED = (function() {
  try {
    if (typeof WebAssembly === 'undefined' || typeof WebAssembly.validate !== 'function') return false;
    var bytes = new Uint8Array([0,97,115,109,1,0,0,0,1,5,1,96,0,1,123,3,2,1,0,10,15,1,13,0,65,1,253,15,65,2,253,15,253,128,2,11]);
    return WebAssembly.validate(bytes);
  } catch (e) { return false; }
})();
var ENGINE_PREFIX = USE_RELAXED ? 'pikafish.relaxed' : 'pikafish';

PikafishUciSearch.prototype._downloadEngine = function() {
  var self = this;
  var base = getAssetBaseXqw();

  return fetch(base + 'wasm/' + ENGINE_PREFIX + '.wasm' + ENGINE_QUERY).then(function(resp) {
    if (!resp.ok) throw new Error('WASM 下载失败: HTTP ' + resp.status);
    return resp.arrayBuffer();
  }).then(function(ab) {
    self.wasmBinary = ab;
    return fetch(base + 'wasm/' + ENGINE_PREFIX + '.js' + ENGINE_QUERY);
  }).then(function(resp) {
    if (!resp.ok) throw new Error('JS 下载失败: HTTP ' + resp.status);
    return resp.text();
  }).then(function(txt) {
    self.engineJs = txt;
    // NNUE 使用固定 URL（无版本号），保证权重不变时命中离线缓存
    return fetch(base + 'wasm/pikafish.nnue');
  }).then(function(resp) {
    if (!resp.ok) throw new Error('NNUE 下载失败: HTTP ' + resp.status);
    return resp.arrayBuffer();
  }).then(function(ab) {
    self.nnueData = ab;
  });
};

function getAssetBaseXqw() {
  var path = location.pathname;
  path = path.substring(0, path.lastIndexOf('/') + 1);
  return location.origin + path;
}

/* 启动引擎并发送初始化命令 (uci / isready)。
 * Worker 只创建一次，引擎初始化后常驻。 */
PikafishUciSearch.prototype.startEngine = function() {
  var self = this;
  return new Promise(function(resolve, reject) {
    if (self.engineReady && self.worker) {
      resolve();
      return;
    }

    // 终止旧的 worker（如果存在）
    if (self.worker) {
      try { self.worker.terminate(); } catch(e) {}
      self.worker = null;
    }

    self.stdoutBuffer = [];
    self.bestmove = "";

    var worker = new Worker('worker.js');
    self.worker = worker;

    /* 统一的 onmessage 处理：同时处理 startEngine 和 searchUci 的回调 */
    worker.onmessage = function(ev) {
      var msg = ev.data;
      if (!msg || !msg.type) return;

      switch (msg.type) {
        case 'stdout':
          self.stdoutBuffer.push(msg.text);
          if (msg.text.indexOf('info ') === 0) {
            self._parseInfo(msg.text);
          }
          if (self.onUciStdout) self.onUciStdout(msg.text);
          if (msg.text.indexOf('bestmove ') === 0) {
            self.bestmove = msg.text;
          }
          break;

        case 'stderr':
          if (self.onUciStderr) self.onUciStderr(msg.text);
          break;

        case 'debug':
          if (self.onUciDebug) self.onUciDebug(msg.text);
          break;

        case 'ready':
          self.engineReady = true;
          resolve();
          break;

        case 'done':
          // 只处理当前活跃搜索的 done 消息
          if (self._pendingSearch && msg.searchId === self._pendingSearch.searchId) {
            var ps = self._pendingSearch;
            self._pendingSearch = null;
            if (ps.timeoutId) clearTimeout(ps.timeoutId);
            var uciMove = self._parseBestmove(self.bestmove);
            if (uciMove) {
              if (self.onUciStdout) self.onUciStdout('[UCI←] bestmove ' + uciMove);
              var xqwMove = uciToXqwMove(uciMove);
              if (self.onUciStdout) self.onUciStdout('[调试] xqwMove=' + xqwMove + '  src=' + (xqwMove & 255) + '  dst=' + (xqwMove >> 8));
              ps.resolve(xqwMove);
            } else {
              ps.reject(new Error('未获取到 bestmove'));
            }
          }
          break;

        case 'error':
          self.engineReady = false;
          if (self._pendingSearch) {
            var ps = self._pendingSearch;
            self._pendingSearch = null;
            if (ps.timeoutId) clearTimeout(ps.timeoutId);
            ps.reject(new Error(msg.text));
          } else {
            reject(new Error(msg.text));
          }
          break;
      }
    };

    worker.onerror = function(ev) {
      reject(new Error('Worker 错误: ' + ev.message));
    };

    // 发送初始化命令（worker 内部会执行 uci + isready）
    worker.postMessage({
      type: 'init',
      wasmBinary: self.wasmBinary,
      engineJs: self.engineJs,
      nnueData: self.nnueData
    });
  });
};

/* 执行 UCI 搜索，返回 bestmove 对应的 xqwlight move。
 * 使用常驻 Worker：不终止旧 Worker，直接发送新搜索命令。
 * 如果前一个搜索仍在运行，其 Promise 会被 reject。
 * 如果 Worker 不存在（被 restart 终止），自动重建。 */
PikafishUciSearch.prototype.searchUci = function(fen, movesList, movetimeMs, hasStartFen) {
  var self = this;

  // 如果 Worker 被终止（如点击重新开始），自动重建
  if (!self.worker || !self.engineReady) {
    return self.startEngine().then(function() {
      return self.searchUci(fen, movesList, movetimeMs, hasStartFen);
    });
  }

  // 1) 作废上一次未结束的搜索 Promise
  if (self._pendingSearch) {
    var prev = self._pendingSearch;
    self._pendingSearch = null;
    if (prev.timeoutId) clearTimeout(prev.timeoutId);
    try { prev.reject(new Error('__superseded__')); } catch (e) {}
  }

  return new Promise(function(resolve, reject) {
    var searchId = ++self._currentSearchId;

    // 构建 UCI 命令
    var commands = [];

    // 必须有开局 FEN 才能附加 moves 历史（否则 moves 会从当前局面重复走棋）
    // 附带 moves 历史让引擎能检测与历史局面的重复（长将/长捉违规）
    var posCmd = "position fen " + fen;
    if (hasStartFen && movesList && movesList.length > 0) {
      posCmd += " moves " + movesList.join(" ");
    }
    commands.push(posCmd);
    commands.push("go movetime " + movetimeMs);

    // 显示 FEN 供调试
    if (self.onUciStdout) {
      var debugMoves = (hasStartFen && movesList && movesList.length > 0) ? movesList.join(',') : '无';
      self.onUciStdout('[调试] fen=' + fen + '  moves=' + debugMoves + '  hasStartFen=' + hasStartFen);
    }

    // 发送 UCI 命令提醒
    var reminders = self.uciReminders;
    for (var i = 0; i < reminders.length; i++) {
      if (self.onUciStdout) self.onUciStdout('[棋规] ' + reminders[i]);
    }
    for (var i = 0; i < commands.length; i++) {
      if (self.onUciStdout) self.onUciStdout('[UCI→] ' + commands[i]);
    }

    self.stdoutBuffer = [];
    self.bestmove = "";

    // 存储当前搜索的 Promise 回调
    var timeoutMs = Math.max(movetimeMs + 15000, 30000);
    var timeoutId = setTimeout(function() {
      if (self._pendingSearch && self._pendingSearch.searchId === searchId) {
        var ps = self._pendingSearch;
        self._pendingSearch = null;
        if (self.onUciStderr) self.onUciStderr('[错误] 搜索超时 (' + timeoutMs + 'ms)');
        ps.reject(new Error('搜索超时'));
      }
    }, timeoutMs);

    self._pendingSearch = {
      resolve: resolve,
      reject: reject,
      searchId: searchId,
      timeoutId: timeoutId
    };

    // 向常驻 Worker 发送搜索命令
    self.worker.postMessage({
      type: 'search',
      commands: commands,
      searchId: searchId
    });
  });
};

/* 从 stdout 中解析 info depth/score/nodes/pv 并存储到 lastInfo */
PikafishUciSearch.prototype._parseInfo = function(line) {
  if (line.indexOf('info ') !== 0) return;
  // 只处理包含 pv 的 info 行
  if (line.indexOf(' pv ') < 0) return;
  var self = this;
  var info = { depth: '?', scoreType: '', score: 0, nodes: '?', pv: [] };

  // depth N
  var m = line.match(/\bdepth\s+(\d+)/);
  if (m) info.depth = m[1];

  // score cp N 或 score mate N
  var m2 = line.match(/\bscore\s+(cp|mate)\s+([-\d]+)/);
  if (m2) {
    if (m2[1] === 'mate') {
      var mateSteps = parseInt(m2[2]);
      if (mateSteps >= 0) {
        info.scoreType = 'mate';
        info.score = mateSteps;
      } else {
        info.scoreType = 'mated';
        info.score = Math.abs(mateSteps);
      }
    } else {
      info.scoreType = 'cp';
      info.score = parseInt(m2[2]);
    }
  }

  // nodes N
  var m3 = line.match(/\bnodes\s+(\d+)/);
  if (m3) info.nodes = m3[1];

  // pv ... (从 pv 开始到行尾)
  var pvIdx = line.indexOf(' pv ');
  if (pvIdx >= 0) {
    var pvStr = line.substring(pvIdx + 4).trim();
    info.pv = pvStr.split(/\s+/).filter(function(s) { return s.length >= 4; });
  }

  self.lastInfo = info;

  // 实时通知外部（UI 更新）
  if (self.onInfo) {
    self.onInfo(info);
  }
};

/* 从 stdout 中解析 bestmove */
PikafishUciSearch.prototype._parseBestmove = function(bestmoveLine) {
  if (!bestmoveLine) return "";
  // "bestmove e2e4" 或 "bestmove e2e4 ponder e7e5"
  var parts = bestmoveLine.split(/\s+/);
  if (parts.length >= 2 && parts[0] === 'bestmove') {
    return parts[1];
  }
  return "";
};

/* 获取开局 FEN 和全部历史着法（用于 UCI position 命令的完整历史重放） */
PikafishUciSearch.prototype._getFenWithMoves = function() {
  var pos = this.pos;

  // 使用开局 FEN（如果未设置则回退到当前局面 FEN）
  var fen = this.startFen;
  if (!fen) {
    // 从当前局面构建 FEN
    fen = "";
    for (var y = 3; y <= 12; y++) {
      var emptyCount = 0;
      for (var x = 3; x <= 11; x++) {
        var sq = x + (y << 4);
        var pc = pos.squares[sq];
        if (pc === 0) {
          emptyCount++;
        } else {
          if (emptyCount > 0) {
            fen += emptyCount;
            emptyCount = 0;
          }
          var pieceChar = "";
          var pieceType = pc & 7;
          var side = pc >> 3;
          switch (pieceType) {
            case 0: pieceChar = "K"; break;
            case 1: pieceChar = "A"; break;
            case 2: pieceChar = "B"; break;
            case 3: pieceChar = "N"; break;
            case 4: pieceChar = "R"; break;
            case 5: pieceChar = "C"; break;
            case 6: pieceChar = "P"; break;
          }
          if (pieceChar) {
            fen += (side === 1 ? pieceChar : pieceChar.toLowerCase());
          }
        }
      }
      if (emptyCount > 0) fen += emptyCount;
      if (y < 12) fen += "/";
    }
    fen += " " + (pos.sdPlayer === 0 ? "w" : "b");
  }

  // 构建 moves 列表（从初始位置到当前走法）
  var moves = [];
  var mvList = pos.mvList;
  if (mvList && mvList.length > 1) {
    for (var i = 1; i < mvList.length; i++) {
      var mv = mvList[i];
      if (mv > 0) {
        moves.push(xqwMoveToUci(mv));
      }
    }
  }

  return { fen: fen, moves: moves, hasStartFen: !!this.startFen };
};

/* ---------- searchMain(depth, millis) ----------
 *  兼容 board.js 的调用方式
 *  board.js 调用: board.search.searchMain(LIMIT_DEPTH, board.millis)
 *  返回 bestmove 对应的 xqwlight move 整数
 *  注意：由于是异步操作，实际通过 Promise 解析，board.js 需要适配
 *  此处采用回调方式
 */
PikafishUciSearch.prototype.searchMain = function(depth, millis, callback) {
  var self = this;

  // 获取当前局面 FEN
  var posData = self._getFenWithMoves();

  // 执行 UCI 搜索
  self.searchUci(posData.fen, posData.moves, millis, posData.hasStartFen).then(function(xqwMove) {
    if (callback) {
      callback(xqwMove);
    }
  }).catch(function(err) {
    // 被新搜索主动取代的旧搜索（用户改设置 / 重新开始 / 悔棋触发的下一次搜索），
    // 这是预期行为，不向用户报告"搜索失败"
    if (err && err.message === '__superseded__') {
      if (callback) callback(0);
      return;
    }
    if (self.onUciStderr) {
      self.onUciStderr('[错误] 搜索失败: ' + err.message);
    }
    if (callback) {
      callback(0);
    }
  });
};

/* 向引擎发送 stop 命令，终止当前搜索 */
PikafishUciSearch.prototype.stopEngine = function() {
  var self = this;
  if (self.worker && self.engineReady) {
    self.worker.postMessage({ type: 'stop' });
  }
};